import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://kwharrison13.com',
});
