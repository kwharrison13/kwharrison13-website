---
title: "Let Me Know How I Can Be Helpful"
date: "2022-01-01"
tag: "VC Behavior"
excerpt: ""
---

[Let Me Know How I Can Be Helpful](https://investing1012dot0.substack.com/p/let-me-know-how-i-can-be-helpful)