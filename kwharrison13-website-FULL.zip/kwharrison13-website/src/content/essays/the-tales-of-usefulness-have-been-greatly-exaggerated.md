---
title: "The Tales of Usefulness Have Been Greatly Exaggerated"
date: "2022-01-01"
tag: "VC Behavior"
excerpt: ""
---

[The Tales of Usefulness Have Been Greatly Exaggerated](https://investing1012dot0.substack.com/p/the-tales-of-their-usefulness-have)